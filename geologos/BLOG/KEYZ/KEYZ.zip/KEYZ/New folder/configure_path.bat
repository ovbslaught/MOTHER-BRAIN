@echo off
setlocal enabledelayedexpansion

:: ========================================
:: PATH CONFIGURATION SCRIPT
:: Configures system PATH for all development tools
:: ========================================

title PATH Configuration
color 0E

echo ========================================
echo PATH CONFIGURATION SCRIPT
echo ========================================
echo.

:: Check if running as administrator
net session >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo WARNING: Not running as administrator.
    echo This script can only modify PATH for the current user.
    echo For system-wide PATH changes, run as administrator.
    echo.
)

:: Define paths to add
set "PYTHON_PATHS="
set "GIT_PATHS=C:\Program Files\Git\bin;C:\Program Files\Git\cmd"
set "NODE_PATHS=%APPDATA%\npm"
set "DEV_PATHS=%USERPROFILE%\Development\Tools;%USERPROFILE%\Development\Scripts"
set "LLAMA_PATHS=%USERPROFILE%\llama_integration_scripts"
set "VS_CODE_PATHS=C:\Program Files\Microsoft VS Code\bin"
set "BLENDER_PATHS=C:\Program Files\Blender Foundation\Blender 3.x"
set "FFMPEG_PATHS=C:\ffmpeg\bin"
set "CUDA_PATHS=C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\bin;C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\libnvvp"

:: Get current Python installation paths
python -c "import sys; print(';'.join(sys.path))" 2>nul > temp_python_path.txt
if exist temp_python_path.txt set /p PYTHON_PATHS=<temp_python_path.txt
if exist temp_python_path.txt del temp_python_path.txt
for /f "tokens=*" %%i in ('where python 2^>nul') do set "PYTHON_DIR=%%~dpi"
if defined PYTHON_DIR set "PYTHON_PATHS=%PYTHON_DIR%;%PYTHON_PATHS%"

:: Combine all paths
set "ALL_PATHS=%PYTHON_PATHS%;%GIT_PATHS%;%NODE_PATHS%;%DEV_PATHS%;%LLAMA_PATHS%;%VS_CODE_PATHS%;%BLENDER_PATHS%;%FFMPEG_PATHS%;%CUDA_PATHS%"

:: Get current PATH
set "CURRENT_PATH=%PATH%"

:: Check which paths are already in PATH
echo Checking current PATH configuration...
echo.

set "NEW_PATHS="
for %%p in ("%ALL_PATHS:;=" "%") do (
    set "CHECK_PATH=%%~p"
    if defined CHECK_PATH if not "!CHECK_PATH!"=="" (
        echo "!CURRENT_PATH!" | findstr /C:"!CHECK_PATH!" >nul
        if !ERRORLEVEL! neq 0 (
            if exist "!CHECK_PATH!" (
                echo   Adding: !CHECK_PATH!
                set "NEW_PATHS=!NEW_PATHS!!CHECK_PATH!;"
            ) else (
                echo   Skipping (not found): !CHECK_PATH!
            )
        ) else (
            echo   Already in PATH: !CHECK_PATH!
        )
    )
)

echo.
if defined NEW_PATHS (
    echo Updating PATH for current session...
    set "PATH=%NEW_PATHS%%PATH%"
    echo PATH updated successfully!
) else (
    echo No new paths to add.
)

:: Create permanent PATH update script
set "PATH_UPDATE_SCRIPT=%USERPROFILE%\Development\Scripts\update_path.bat"
if not exist "%USERPROFILE%\Development\Scripts" mkdir "%USERPROFILE%\Development\Scripts"

(
    echo @echo off
    echo echo Updating PATH...
    echo set "NEW_PATHS=%NEW_PATHS%"
    echo if defined NEW_PATHS set "PATH=%%NEW_PATHS%%%%PATH%%"
    echo echo PATH updated.
) > "%PATH_UPDATE_SCRIPT%"

echo.
echo Created PATH update script: %PATH_UPDATE_SCRIPT%
echo.

:: Test key tools
echo Testing tool availability...
echo.

:: Test Python
python --version >nul 2>&1
if %ERRORLEVEL% equ 0 (
    for /f "tokens=*" %%i in ('python --version') do echo   Python: %%i
) else (
    echo   Python: NOT FOUND
)

:: Test Git
git --version >nul 2>&1
if %ERRORLEVEL% equ 0 (
    for /f "tokens=1,2,3" %%i in ('git --version') do echo   Git: %%i %%j %%k
) else (
    echo   Git: NOT FOUND
)

:: Test Node.js
node --version >nul 2>&1
if %ERRORLEVEL% equ 0 (
    for /f "tokens=*" %%i in ('node --version') do echo   Node.js: %%i
) else (
    echo   Node.js: NOT FOUND
)

:: Test VS Code
code --version >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo   VS Code: AVAILABLE
) else (
    echo   VS Code: NOT FOUND
)

echo.
echo ========================================
echo PATH CONFIGURATION COMPLETE
echo ========================================
echo.
echo Current session PATH has been updated.
echo.
echo To make PATH changes permanent:
echo 1. Run as administrator and choose system-wide update
echo 2. Or add the PATH update script to your startup folder
echo 3. Or manually add paths to System Environment Variables
echo.
echo PATH update script created at:
echo %PATH_UPDATE_SCRIPT%
echo.
pause